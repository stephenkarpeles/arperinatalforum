<?php
/**
 * AmazonSimpleAffiliate (ASA2)
 * For more information see http://www.wp-amazon-plugin.com/
 * 
 * 
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id: IfwFeedAjax.php 1248505 2015-09-18 13:49:54Z worschtebrot $
 */ 
class IfwPsn_Wp_Plugin_Metabox_IfwFeedAjax extends IfwPsn_Wp_Plugin_Metabox_FeedAjax
{
    public $action = 'load-ifw-feed';
}

<?php
/**
 * ifeelweb.de Wordpress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 *
 *
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id: Deactivate.php 1312332 2015-12-19 13:29:57Z worschtebrot $
 */
class IfwPsn_Wp_Plugin_Update_Api_Response_Deactivate extends IfwPsn_Wp_Plugin_Update_Api_Response_Abstract
{

}

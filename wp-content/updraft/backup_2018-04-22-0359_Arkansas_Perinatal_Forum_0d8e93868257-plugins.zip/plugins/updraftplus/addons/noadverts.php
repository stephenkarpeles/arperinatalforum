<?php
// @codingStandardsIgnoreStart
/*
UpdraftPlus Addon: noadverts:No Adverts
Description: Removes all advertising from the UpdraftPlus settings and emails
Version: 1.1
Shop: /shop/no-adverts/
Latest Change: 1.9.19
*/
// @codingStandardsIgnoreEnd

if (!defined('UPDRAFTPLUS_DIR')) die('No direct access allowed');
define('UPDRAFTPLUS_NOADS_B', true);

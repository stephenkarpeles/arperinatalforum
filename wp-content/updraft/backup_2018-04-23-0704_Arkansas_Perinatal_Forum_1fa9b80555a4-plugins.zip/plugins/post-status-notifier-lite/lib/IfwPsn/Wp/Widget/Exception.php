<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 * 
 * Widget Exception
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id: Exception.php 911603 2014-05-10 10:58:23Z worschtebrot $
 */
class IfwPsn_Wp_Widget_Exception extends IfwPsn_Wp_Exception
{}

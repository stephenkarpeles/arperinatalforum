<div class="feat-post">
  <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/mom_baby.jpg" alt="">
  <div class="feat-post__content">
    <div class="feat-post__date">
      March 16, 2018
    </div>
    <div class="feat-post__excerpt">
      This is a news post title that cuts off after something like 75 characters or so…
    </div> 
    <div class="feat-post__cta">
      <a href="">Read more</a>
    </div>           
  </div>
</div>
<a id="backToTop" href="#top">
  Return to Top <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icon-arrow-dark-up.svg" alt="">
</a>
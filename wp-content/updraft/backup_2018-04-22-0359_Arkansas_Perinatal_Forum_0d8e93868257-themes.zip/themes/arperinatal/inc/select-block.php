<div class="select-block">
	<div class="select-block__wrap">
		<div class="select-block__label">
			Jump to a Workgroup:
		</div>
		<div class="select-block__cta">
			Select a Workgroup…
		</div>
	</div>
	<div class="select-block__btn">
		Go
	</div>
</div>
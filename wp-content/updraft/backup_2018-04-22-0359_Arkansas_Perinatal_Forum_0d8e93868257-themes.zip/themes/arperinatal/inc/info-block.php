<div class="info-block">
	<div class="info-block__title">
		ANSG
	</div>
	<div class="info-block__content">
		<div>
			1915 W. Richards St.<br>
      North Little Rock, AR 72211
		</div>
		<div>
			501.891.4390
		</div>
		<div>
			<a href="">Email Us</a> 
		</div>
		<div>
			<a href="">Website<img class="has-link-image" src="<?php echo get_stylesheet_directory_uri(); ?>/img/icon-external-link-dark.svg" alt=""></a>			
		</div>
		<div>
			<a href="">Facebook<img class="has-link-image" src="<?php echo get_stylesheet_directory_uri(); ?>/img/icon-external-link-dark.svg" alt=""></a>			
		</div>
		<div>
			<a href="">Twitter<img class="has-link-image" src="<?php echo get_stylesheet_directory_uri(); ?>/img/icon-external-link-dark.svg" alt=""></a>			
		</div>

		<h2>Primary Contact</h2>
		<div class="name">Dr. Lisa Simmons</div>
		<div class="name">James L. Jennings</div>
	</div>
</div>
<div class="feat-heading">
  <div class="feat-heading__content">
    <span>Upcoming</span>
    <span>Events</span>
  </div>
</div>

<div class="event-listing">
  <div class="event-listing__event">
    <div class="event-listing__date">
      March 16, 2018
    </div>
    <div class="event-listing__title">
      <a href="">2018 Perinatal Conference and Women's Health Update</a>
    </div>
  </div>

  <div class="event-listing__event">
    <div class="event-listing__date">
      April 2, 2018
    </div>
    <div class="event-listing__title">
      <a href="">12th Annual Perinatal &amp; Neonatal Care Seminar</a>
    </div>
  </div>

  <div class="event-listing__more-link">
    <a href="">Find more events</a>
  </div>
</div> 
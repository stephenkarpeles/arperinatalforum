<?php
/**
 * Error controller
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id: PsnErrorController.php 911603 2014-05-10 10:58:23Z worschtebrot $
 * @package  IfwPsn_Wp
 */
class PsnErrorController extends IfwPsn_Zend_Controller_Error
{
}

<?php include('inc/header.php') ?>

<section class="hero" style="background: url('img/apf_home-header.jpg') no-repeat; background-size: cover; background-position: center center;">
	<div class="hero__overlay"></div>
</section>

<?php include('inc/footer.php') ?>
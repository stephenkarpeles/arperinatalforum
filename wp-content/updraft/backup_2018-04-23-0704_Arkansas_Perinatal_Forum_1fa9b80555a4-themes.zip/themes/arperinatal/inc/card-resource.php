<div class="card card--resource">
  <div class="card__resource-type">
    <span>PDF</span>
  </div>
  <div class="card__title">
    <h3>This is the title of this resource that is in alphabetical order</h3>
  </div>
  <div class="card__content">
    <div class="card__description">
      ResourceName2018.pdf
    </div>
    <div class="card__link">
      <a href="#">Visit Link</a>
    </div>
  </div>
</div>
<div class="filter">
  <div class="filter__title">
    Show:
  </div>
  <div class="filter__filters">
    <div class="filter__choice">
      <input type="checkbox" id="newsEvents" name="newsevents" value="newsevents">
      <label for="newsEvents">News &amp; Events</label>
    </div>
    <div class="filter__choice">
      <input type="checkbox" id="newsOnly" name="news" value="news">
      <label for="newsOnly">News Only</label>
    </div>
    <div class="filter__choice">
      <input type="checkbox" id="eventsOnly" name="events" value="events">
      <label for="eventsOnly">Events Only</label>
    </div>
  </div>
</div>
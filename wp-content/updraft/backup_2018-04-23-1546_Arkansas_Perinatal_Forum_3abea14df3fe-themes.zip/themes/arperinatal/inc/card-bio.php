<div class="card card--bio">
  <div class="card__title">
    <h3>Erin Gildner</h3>
    <span>Section Chief for Administration | Arkansas Perinatal Forum Project Manager</span>
  </div>
  <div class="card__content">
    <div class="card__contact">
      <a href="tel:501.891.4390">501.891.4390</a>
      <a href="#">Email Erin</a>
    </div>
    <div class="card__description">
      This is a very brief bio of this person. I would keep this less than around 200 characters. This area can accomodate a lot of copy, but it’s optimized for a more moderate amount. Vestibulum quam vitae.
    </div>    
  </div>
</div>
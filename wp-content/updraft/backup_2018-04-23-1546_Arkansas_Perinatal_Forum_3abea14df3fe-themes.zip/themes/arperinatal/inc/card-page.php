<div class="card card--page">
  <div class="card__title">
    <h3>Workgroups</h3>
  </div>
  <div class="card__content">
    <div class="card__description">
      Vestibulum rutrum quam vitae fringilla tincidunt. Suspendisse nec tortor urna.
    </div>
    <div class="card__link">
      <a href="#">Visit Page</a>
    </div>
  </div>
</div>
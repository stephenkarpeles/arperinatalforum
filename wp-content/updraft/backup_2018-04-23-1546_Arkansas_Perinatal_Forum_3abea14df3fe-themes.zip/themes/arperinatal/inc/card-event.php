<div class="card card--event">
  <div class="card__date">
    <span>September 23, 2018</span>
  </div>
  <div class="card__title">
    <h3>2018 Perinatal Conference Women’s Health Update</h3>
  </div>
  <div class="card__content">
    <div class="card__time">
      11AM - 4PM
    </div>
    <div class="card__location">
      Statehouse Convention Center<br>
      Little Rock, AR
    </div>
    <div class="card__link">
      <a href="#">Learn more</a>
    </div>
  </div>
</div>
<div class="card__logo">
  <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/rectangle@2x.png" alt="Alt Tag">
</div>
<div class="card">
  <div class="card__title">
    <h3>Arkansas Newborn Screening Group</h3>
  </div>
  <div class="card__content">
    <div class="card__contact">
      North Little Rock<br>
      <a href="tel:501.891.4390">501.891.4390</a><br>
      <a href="#">Contact Us</a>
    </div>
    <div class="card__description">
      This is a brief description of what this group does…
    </div>
    <div class="card__link">
      <a href="#">Learn more</a>
    </div>
  </div>
</div>
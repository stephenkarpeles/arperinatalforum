<div class="card card--post">
  <div class="card__date">
    February 14, 2018
  </div>
  <div class="card__title">
    <h3>Newborn Screening for Critical Heart Defects Saves Lives</h3>
  </div>
  <div class="card__content">
    <div class="card__description">
      Vestibulum rutrum quam vitae fringilla tincidunt. Suspendisse nec tortor urna.
    </div>
    <div class="card__link">
      <a href="#">Continue Reading</a>
    </div>
  </div>
</div>
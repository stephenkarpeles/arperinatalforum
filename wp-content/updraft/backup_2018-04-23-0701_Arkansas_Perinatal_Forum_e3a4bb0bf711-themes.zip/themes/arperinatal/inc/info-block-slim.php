<div class="info-block info-block--slim">
	<div class="info-block__title">
		<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logo-uams@2x.png" alt="">
	</div>
	<div class="info-block__content">
		<div>
			4301 W. Markham St.<br>
			Little Rock, AR 72205
		</div>
		<div>
			501.891.4390
		</div>
		<div>
			<a href="">Website<img class="has-link-image" src="<?php echo get_stylesheet_directory_uri(); ?>/img/icon-external-link-dark.svg" alt=""></a>			
		</div>
	</div>
</div>
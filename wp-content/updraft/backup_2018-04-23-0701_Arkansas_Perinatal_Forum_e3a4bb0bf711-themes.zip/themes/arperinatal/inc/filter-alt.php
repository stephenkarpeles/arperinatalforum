<div class="filter-alt">
  
  <div class="filter-alt__filters">
    <!--
    <div class="filter-alt__choice">
      <input type="checkbox" id="newsEvents" name="newsevents" value="newsevents">
      <label for="newsEvents">News &amp; Events</label>
    </div>
    -->
    <div class="filter-alt__choice filter-alt__choice--is-selected-choice">
      <input type="checkbox" id="newsOnly" name="news" value="news">
      <label for="newsOnly">Show News</label>
    </div>
    <div class="filter-alt__choice">
      <input type="checkbox" id="eventsOnly" name="events" value="events">
      <label for="eventsOnly">Show Events</label>
    </div>
  </div>
</div>